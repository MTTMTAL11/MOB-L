import 'package:flutter/material.dart';

class listItems{
  String? title;
  String? subtitle;
  IconData? icon;
  Color? color;

  listItems({required this.title,required this.subtitle,required this.icon,this.color});
}