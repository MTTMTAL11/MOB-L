class Cars{
  String brand = "";
  String model = "";
  int engine = 0;
  String color = "";

  Cars(String _brand,String _model,int _engine,String _color){
    this.brand = _brand;
    this.model = _model;
    this.engine = _engine;
    this.color = _color;
  }
}