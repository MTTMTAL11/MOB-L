package com.example.der99

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
