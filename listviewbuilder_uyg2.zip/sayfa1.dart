import 'package:flutter/material.dart';
import 'package:uygulama8/menueklemesinif.dart';
import 'package:uygulama8/menu.dart';

class sayfa1 extends StatefulWidget {
  const sayfa1({super.key});

  @override
  State<sayfa1> createState() => _sayfa1State();
}

class _sayfa1State extends State<sayfa1> {
  List<menueklemesinif> listem = [];

  TextEditingController yemekadi = TextEditingController();
  TextEditingController yemekfiyati = TextEditingController();
  TextEditingController kdvorani = TextEditingController();
  TextEditingController yemekrengi = TextEditingController();
  TextEditingController yemekresmi = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.deepOrangeAccent,
      width: 600,
      height: 800,
      child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              margin: EdgeInsets.fromLTRB(0, 30, 0, 50),
              child: Text("Menuye Ekleme", style: TextStyle(fontSize: 30)),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(0, 20, 0, 20),
              width: 300,
              child: TextField(
                controller: yemekadi,
                decoration: InputDecoration(labelText: "Yemek Adı"),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(0, 20, 0, 20),
              width: 300,
              child: TextField(
                controller: yemekfiyati,
                decoration: InputDecoration(labelText: "Yemek Fiyatı"),
              ),
            ),
            Container(
              width: 300,
              margin: EdgeInsets.fromLTRB(0, 20, 0, 20),
              child: TextField(
                controller: yemekrengi,
                decoration: InputDecoration(labelText: "Yemek Rengi (amber, purpleaccent, red)"),
              ),
            ),
            Container(
              width: 300,
              margin: EdgeInsets.fromLTRB(0, 20, 0, 20),
              child: TextField(
                controller: yemekresmi,
                decoration: InputDecoration(labelText: "Yemek Resmi (1, 2, 3)"),
              ),
            ),
            Container(
              width: 300,
              height: 45,
              margin: EdgeInsets.fromLTRB(0, 40, 0, 10),
              child: TextButton(
                style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.red)),
                onPressed: () {
                  setState(() {
                    menueklemesinif menuekleme = menueklemesinif();
                    menuekleme.yemekadi = yemekadi.text;
                    menuekleme.yemekfiyati = yemekfiyati.text;
                    if (yemekrengi.text == "amber") {menuekleme.yemekrenk = Colors.amber;}
                    else if (yemekrengi.text == "purpleaccent") {menuekleme.yemekrenk = Colors.purpleAccent;}
                    else if (yemekrengi.text == "red") {menuekleme.yemekrenk = Colors.red;}
                    if (yemekresmi.text == "1") {menuekleme.yemekresim = "1";}
                    else if (yemekresmi.text == "2") {menuekleme.yemekresim = "2";}
                    else if (yemekresmi.text == "3") {menuekleme.yemekresim = "3";}
                    listem.add(menuekleme);
                  });
                },
                child: Text(
                  "Ekle",
                  style: TextStyle(color: Colors.black),
                ),
              ),
            ),
            Container(
              width: 120,
              height: 45,
              margin: EdgeInsets.fromLTRB(0, 10, 0, 30),
              child: TextButton(
                style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.red)),
                onPressed: () {
                  setState(() {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => menu(listem: listem),));
                  });
                },
                child: Text(
                  "Menüye geç →",
                  style: TextStyle(color: Colors.black),
                ),
              ),
            ),
          ]),
    );
  }
}
