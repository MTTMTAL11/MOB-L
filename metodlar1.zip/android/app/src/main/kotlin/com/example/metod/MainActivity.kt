package com.example.metod

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
