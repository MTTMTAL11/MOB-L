import 'package:flutter/material.dart';
import 'package:uygulama8/sayfa1.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Scaffold(
        body: Center(
      child: sayfa1(),
    )),
  ));
}
