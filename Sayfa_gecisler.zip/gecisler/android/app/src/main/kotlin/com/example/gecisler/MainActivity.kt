package com.example.gecisler

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
