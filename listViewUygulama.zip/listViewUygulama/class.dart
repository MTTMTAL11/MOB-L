import 'package:flutter/material.dart';

class anasayfa extends StatefulWidget {
  const anasayfa({super.key});

  @override
  State<anasayfa> createState() => _anasayfaState();
}

class _anasayfaState extends State<anasayfa> {
  List<String> isimListe = [];
  List<String> soyisimListe = [];
  List<String> cinsiyetListe = [];
  List<Color> cinsiyetRenk = [];

  int cinsiyetRadioDeger = 1;
  String cinsiyet = "";
  TextEditingController isim = TextEditingController();
  TextEditingController soyisim = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                    width: 200,
                    height: 55,
                    child: TextField(controller: isim, decoration: InputDecoration(labelText: "İsim"),)
                ),
                Container(
                    width: 200,
                    height: 55,
                    child: TextField(controller: soyisim, decoration: InputDecoration(labelText: "Soyisim"))
                ),
                Row(children: [
                  Container(margin: EdgeInsets.fromLTRB(0, 10, 10, 0), child: Text("Erkek"),),
                  Container(margin: EdgeInsets.fromLTRB(0, 10, 20, 0), child: Radio(value: 0, groupValue: cinsiyetRadioDeger, onChanged: (value) {
                    setState(() {
                      cinsiyetRadioDeger = value!;
                      if (value! == 1) {
                        cinsiyet = "Kız";
                      }
                      else {
                        cinsiyet = "Erkek";
                      }
                    });
                  },),),
                  Container(margin: EdgeInsets.fromLTRB(0, 10, 10, 0), child: Text("Kız"),),
                  Container(margin: EdgeInsets.fromLTRB(0, 10, 0, 0), child: Radio(value: 2, groupValue: cinsiyetRadioDeger, onChanged: (value) {
                    setState(() {
                      cinsiyetRadioDeger = value!;
                      if (value! == 1) {
                        cinsiyet = "Erkek";
                      }
                      else {
                        cinsiyet = "Kız";
                      }
                    });
                  },),),
                ],),
                Container(
                  width: 150,
                  height: 45,
                  margin: EdgeInsets.fromLTRB(0, 20, 0, 20),
                  child: TextButton(
                    style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.all(Colors.black)),
                    onPressed: () {
                      setState(() {
                        isimListe.add(isim.text);
                        soyisimListe.add(soyisim.text);
                        cinsiyetListe.add(cinsiyet);
                        if (cinsiyet == "Erkek") {
                          cinsiyetRenk.add(Colors.blue);
                        }
                        else {
                          cinsiyetRenk.add(Colors.pink);
                        }
                      });
                    },
                    child: Text("Kaydet", style: TextStyle(color: Colors.white)),
                  ),
                ),
                Container(
                  width: 300,
                  height: 200,
                  child: ListView.builder(itemCount: isimListe.length, itemBuilder: (context, index) {
                    return ListTile(
                      tileColor: cinsiyetRenk[index],
                      title: Text(isimListe[index]),
                      subtitle: Text(soyisimListe[index]),
                      trailing: IconButton(icon: Icon(Icons.remove_circle), onPressed: () {
                        setState(() {
                          isimListe.removeAt(index);
                          soyisimListe.removeAt(index);
                          cinsiyetListe.removeAt(index);
                          cinsiyetRenk.removeAt(index);
                        });
                      },),
                    );
                  },)
                )
            ],),

        ],)
    ],);
  }
}
