package com.example.ders7

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
