import 'package:flutter/material.dart';

import 'class.dart';

void main() {
  runApp(MaterialApp(
    home: Scaffold(
        body: Center(
      child: Container(
        width: 350,
        height: 600,
        decoration: BoxDecoration(borderRadius: BorderRadius.all(Radius.circular(15)), border: Border.all(width: 2, color: Colors.grey)),
        child: anasayfa(),
      ),
    )),
  ));
}
