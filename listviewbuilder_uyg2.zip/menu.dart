import 'package:flutter/material.dart';
import 'package:uygulama8/menueklemesinif.dart';
import 'package:uygulama8/sayfa1.dart';

class menu extends StatefulWidget {
  List<menueklemesinif> listem = [];
  menu({super.key, required this.listem});

  @override
  State<menu> createState() => _menuState();
}

class _menuState extends State<menu> {
  int toplamfiyat = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Container(
          width: 600,
          height: 700,

          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 500,
                height: 400,
                child: ListView.builder(
                  itemCount: widget.listem.length,
                  itemBuilder: (context, index) {
                    return ListTile(
                      tileColor: widget.listem[index].yemekrenk,
                      title: Text(widget.listem[index].yemekadi.toString()),
                      subtitle: Text(widget.listem[index].yemekfiyati.toString() + " TL"),
                      trailing: IconButton(icon: Icon(Icons.add), onPressed: () {
                        setState(() {
                          toplamfiyat += int.parse(widget.listem[index].yemekfiyati.toString());
                        });
                      },),
                      leading: CircleAvatar(radius: 30.0, backgroundImage: AssetImage("resimler/" + widget.listem[index].yemekresim.toString() + ".png")),
                    );
                  },
                ),
              ),
              Container(
                margin: EdgeInsets.fromLTRB(0, 10, 0, 10),
                width: 300,
                height: 70,
                child: Text("Toplam Fiyat: " + toplamfiyat.toString() + "TL", textAlign: TextAlign.center, style: TextStyle(fontSize: 20),),
              ),
              Container(
                width: 120,
                height: 45,
                margin: EdgeInsets.fromLTRB(0, 10, 0, 30),
                child: TextButton(
                  style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all(Colors.red)),
                  onPressed: () {
                    setState(() {
                      Navigator.pop(context);
                    });
                  },
                  child: Text(
                    "Sayfa 1'e geç →",
                    style: TextStyle(color: Colors.black),
                  ),
                ),
              ),
            ],
          ),
        )
      ),
    );
  }
}
