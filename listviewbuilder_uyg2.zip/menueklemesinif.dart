import 'package:flutter/material.dart';

class menueklemesinif {
  String? yemekadi;
  String? yemekfiyati;
  Color? yemekrenk;
  String? yemekresim;

  menueklemesinif({this.yemekadi, this.yemekfiyati, this.yemekrenk, this.yemekresim});
}