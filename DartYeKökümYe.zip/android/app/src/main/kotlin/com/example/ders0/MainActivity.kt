package com.example.ders0

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
