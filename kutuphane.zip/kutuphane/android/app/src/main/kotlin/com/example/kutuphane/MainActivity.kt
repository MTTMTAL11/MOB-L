package com.example.kutuphane

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
