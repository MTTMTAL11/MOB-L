package com.example.ders22

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
